create function postgis_scripts_installed() returns text
    immutable
    language sql
as
$$
SELECT trim('3.2.1'::text || $rev$ 3.2.1 $rev$) AS version
$$;

comment on function postgis_scripts_installed() is 'Returns version of the PostGIS scripts installed in this database.';

alter function postgis_scripts_installed() owner to postgres;

